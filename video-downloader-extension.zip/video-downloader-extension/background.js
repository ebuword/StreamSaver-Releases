// Video Stream Finder - Background Service Worker

// Store found video URLs per tab
const videoUrls = new Map();

// Video file patterns to detect
const VIDEO_PATTERNS = [
    /\.m3u8(\?|$)/i,
    /\.mp4(\?|$)/i,
    /\.webm(\?|$)/i,
    /\.ts(\?|$)/i,
    /\.flv(\?|$)/i,
    /master\.m3u8/i,
    /index\.m3u8/i,
    /playlist\.m3u8/i,
    /video\//i,
    /stream\//i,
    // CDN patterns
    /imglink\.pro\/.*?m/i,  // imglink.pro CDN often uses /m* paths for media
    /rapidvid\.net\/.*?hls/i,
    /\/hls\//i,
    /\/manifest\//i,
    /seg-\d+-/i,  // HLS segment pattern
    /chunklist/i,
    /media-\d+\.ts/i
];

// Listen for web requests
chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
        const url = details.url;

        // Check if URL matches video patterns
        for (const pattern of VIDEO_PATTERNS) {
            if (pattern.test(url)) {
                addVideoUrl(details.tabId, url, details.type);
                break;
            }
        }

        // Check for agl005.tech iframe with encoded URL
        if (url.includes('agl005.tech/iframe')) {
            decodeAndAddAgl005Url(details.tabId, url);
        }
    },
    { urls: ["<all_urls>"] }
);

// Decode agl005.tech encoded URLs
function decodeAndAddAgl005Url(tabId, iframeUrl) {
    try {
        const match = iframeUrl.match(/\/iframe\/\d+\/([^!?]+)/);
        if (!match) return;

        let encoded = match[1];
        encoded = encoded.replace(/-/g, '+').replace(/_/g, '/');

        let decoded = atob(encoded);
        decoded = decoded
            .replace(/htVps/g, 'https')
            .replace(/aoä/g, 'amd')
            .replace(/strgám/g, 'stream')
            .replace(/strg.m/g, 'stream');

        const urlMatch = decoded.match(/https?:\/\/[^\s"'<>]+/);
        if (urlMatch) {
            let videoUrl = urlMatch[0];
            if (videoUrl.endsWith('/')) {
                videoUrl += 'playlist.m3u8';
            } else if (!videoUrl.includes('.m3u8')) {
                videoUrl += '/playlist.m3u8';
            }

            console.log('[VideoFinder] Decoded agl005 URL:', videoUrl);
            addVideoUrl(tabId, videoUrl, 'decoded');
        }
    } catch (e) {
        console.log('[VideoFinder] Decode error:', e);
    }
}

// Also listen for response headers to check content-type
chrome.webRequest.onHeadersReceived.addListener(
    (details) => {
        const contentType = details.responseHeaders?.find(
            h => h.name.toLowerCase() === 'content-type'
        );

        if (contentType) {
            const type = contentType.value.toLowerCase();
            if (
                type.includes('video/') ||
                type.includes('application/x-mpegurl') ||
                type.includes('application/vnd.apple.mpegurl') ||
                type.includes('application/octet-stream')
            ) {
                addVideoUrl(details.tabId, details.url, 'media');
            }
        }
    },
    { urls: ["<all_urls>"] },
    ["responseHeaders"]
);

// Add video URL to storage
function addVideoUrl(tabId, url, type) {
    if (tabId < 0) return;

    if (!videoUrls.has(tabId)) {
        videoUrls.set(tabId, new Set());
    }

    const urls = videoUrls.get(tabId);
    urls.add(JSON.stringify({ url, type, time: Date.now() }));

    // Update badge
    chrome.action.setBadgeText({
        tabId: tabId,
        text: urls.size.toString()
    });
    chrome.action.setBadgeBackgroundColor({
        tabId: tabId,
        color: '#e50914'
    });

    console.log(`[VideoFinder] Found: ${url}`);
}

// Clear URLs when tab is closed
chrome.tabs.onRemoved.addListener((tabId) => {
    videoUrls.delete(tabId);
});

// Clear URLs when tab navigates to new page
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.status === 'loading') {
        videoUrls.delete(tabId);
        chrome.action.setBadgeText({ tabId, text: '' });
    }
});

// Handle messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'getVideos') {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const tabId = tabs[0]?.id;
            if (tabId && videoUrls.has(tabId)) {
                const urls = Array.from(videoUrls.get(tabId)).map(u => JSON.parse(u));
                sendResponse({ videos: urls });
            } else {
                sendResponse({ videos: [] });
            }
        });
        return true; // Keep channel open for async response
    }

    if (message.type === 'download') {
        chrome.downloads.download({
            url: message.url,
            filename: message.filename || 'video.mp4'
        });
        sendResponse({ success: true });
    }

    if (message.type === 'foundVideo') {
        // Message from content script
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const tabId = tabs[0]?.id;
            if (tabId) {
                addVideoUrl(tabId, message.url, 'page');
            }
        });
    }

    if (message.type === 'foundPlayerIframe') {
        // Player iframe found - store this for reference
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const tabId = tabs[0]?.id;
            if (tabId) {
                addVideoUrl(tabId, message.url, 'player-iframe');
            }
        });
    }
});
