// Video Stream Finder - Popup Script

document.addEventListener('DOMContentLoaded', async () => {
  const statusEl = document.getElementById('status');
  const listEl = document.getElementById('video-list');

  // Get videos from background
  chrome.runtime.sendMessage({ type: 'getVideos' }, (response) => {
    const videos = response?.videos || [];

    if (videos.length === 0) {
      showEmptyState();
    } else {
      showVideos(videos);
    }
  });

  function showEmptyState() {
    statusEl.className = 'status empty';
    statusEl.innerHTML = `
      <span>Video bulunamadı</span>
    `;

    listEl.innerHTML = `
      <div class="empty-state">
        <svg viewBox="0 0 24 24" fill="currentColor">
          <path d="M18 4l2 4h-3l-2-4h-2l2 4h-3l-2-4H8l2 4H7L5 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4h-4zm-6.5 11.5L11 13l-2.5 2.5 1-1V18h3v-3.5l1 1-2-2.5z"/>
        </svg>
        <p>Bu sayfada henüz video tespit edilemedi.</p>
        <p>Videoyu oynatmayı deneyin.</p>
        <div class="tip">
          💡 İpucu: Bazı siteler videoyu yüklemek için "Oynat" butonuna tıklamanızı bekler.
        </div>
      </div>
    `;
  }

  function showVideos(videos) {
    // Deduplicate and sort by time
    const uniqueVideos = [];
    const seen = new Set();

    videos.sort((a, b) => b.time - a.time);

    videos.forEach(v => {
      const urlKey = v.url.split('?')[0]; // Remove query params for dedup
      if (!seen.has(urlKey)) {
        seen.add(urlKey);
        uniqueVideos.push(v);
      }
    });

    statusEl.className = 'status found';
    statusEl.innerHTML = `
      <span>🎬 ${uniqueVideos.length} video bulundu</span>
    `;

    listEl.innerHTML = uniqueVideos.map((video, index) => {
      const format = getFormat(video.url, video.type);
      const shortUrl = video.url.length > 80
        ? video.url.substring(0, 80) + '...'
        : video.url;

      const isStream = format === 'm3u8' || format === 'ts' || format === 'hls' || format === 'player';

      return `
        <div class="video-item">
          <div class="video-url">${escapeHtml(shortUrl)}</div>
          <div class="video-meta">
            <span class="badge ${format}">${format.toUpperCase()}</span>
            ${isStream ? '<span class="badge stream">STREAM</span>' : ''}
          </div>
          <div class="btn-group">
            ${isStream ? `
              <button class="btn btn-primary" data-action="ytdlp" data-url="${escapeHtml(video.url)}">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/>
                </svg>
                yt-dlp
              </button>
            ` : `
              <button class="btn btn-primary" data-action="download" data-url="${escapeHtml(video.url)}" data-index="${index}">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/>
                </svg>
                İndir
              </button>
            `}
            <button class="btn btn-secondary" data-action="copy" data-url="${escapeHtml(video.url)}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                <path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>
              </svg>
            </button>
            <button class="btn btn-secondary" data-action="open" data-url="${escapeHtml(video.url)}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"/>
              </svg>
            </button>
          </div>
        </div>
      `;
    }).join('');

    // Add event listeners
    listEl.querySelectorAll('[data-action]').forEach(btn => {
      btn.addEventListener('click', handleAction);
    });
  }

  function handleAction(e) {
    const btn = e.currentTarget;
    const action = btn.dataset.action;
    const url = btn.dataset.url;

    switch (action) {
      case 'download':
        downloadVideo(url);
        break;
      case 'copy':
        copyToClipboard(url);
        showToast('Link kopyalandı!');
        break;
      case 'open':
        chrome.tabs.create({ url });
        break;
      case 'ytdlp':
        // Get current tab URL for referer
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          const pageUrl = tabs[0]?.url || '';
          const referer = new URL(pageUrl).origin;
          const cmd = `yt-dlp --referer "${referer}" --downloader ffmpeg --hls-use-mpegts -f "bestvideo+bestaudio/best" --merge-output-format mp4 "${url}"`;
          copyToClipboard(cmd);
          showToast('yt-dlp komutu kopyalandı!');
        });
        break;
    }
  }

  function downloadVideo(url) {
    const format = getFormat(url);
    const filename = `video_${Date.now()}.${format === 'm3u8' ? 'ts' : format}`;

    if (format === 'm3u8') {
      showToast('M3U8 stream - yt-dlp kullanın');
      copyToClipboard(url);
    } else {
      chrome.runtime.sendMessage({
        type: 'download',
        url: url,
        filename: filename
      });
      showToast('İndirme başlatıldı!');
    }
  }

  function copyToClipboard(text) {
    navigator.clipboard.writeText(text);
  }

  function showToast(message) {
    const toast = document.createElement('div');
    toast.style.cssText = `
      position: fixed;
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%);
      background: #28a745;
      color: white;
      padding: 10px 20px;
      border-radius: 8px;
      font-size: 13px;
      z-index: 1000;
      animation: fadeIn 0.3s;
    `;
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.remove();
    }, 2000);
  }

  function getFormat(url, type) {
    // Player iframe detection
    if (type === 'player-iframe' || url.includes('rapidvid.net') || url.includes('vidmoxy') || url.includes('closeload')) {
      return 'player';
    }
    // Standard extensions
    if (url.includes('.m3u8')) return 'm3u8';
    if (url.includes('.mp4')) return 'mp4';
    if (url.includes('.webm')) return 'webm';
    if (url.includes('.ts')) return 'ts';
    // CDN HLS detection
    if (url.includes('imglink.pro')) return 'hls';
    if (url.includes('/hls/') || url.includes('/manifest/')) return 'hls';
    return 'other';
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
});
