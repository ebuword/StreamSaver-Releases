// Video Stream Finder - Content Script

(function () {
    'use strict';

    const VIDEO_PATTERNS = [
        /https?:\/\/[^\s"'<>]+\.m3u8[^\s"'<>]*/gi,
        /https?:\/\/[^\s"'<>]+\.mp4[^\s"'<>]*/gi,
        /https?:\/\/[^\s"'<>]+\.webm[^\s"'<>]*/gi,
        /https?:\/\/[^\s"'<>]+\.ts[^\s"'<>]*/gi
    ];

    // Scan page source for video URLs
    function scanPageSource() {
        const pageSource = document.documentElement.outerHTML;
        const foundUrls = new Set();

        VIDEO_PATTERNS.forEach(pattern => {
            const matches = pageSource.match(pattern) || [];
            matches.forEach(url => {
                // Clean up URL
                url = url.replace(/["'<>]/g, '').split('\\')[0];
                if (url && !url.includes('example.com')) {
                    foundUrls.add(url);
                }
            });
        });

        // Send to background
        foundUrls.forEach(url => {
            chrome.runtime.sendMessage({ type: 'foundVideo', url });
        });
    }

    // Monitor for video elements
    function scanVideoElements() {
        document.querySelectorAll('video').forEach(video => {
            if (video.src) {
                chrome.runtime.sendMessage({ type: 'foundVideo', url: video.src });
            }
            video.querySelectorAll('source').forEach(source => {
                if (source.src) {
                    chrome.runtime.sendMessage({ type: 'foundVideo', url: source.src });
                }
            });
        });
    }

    // Monitor iframes for video sources
    function scanIframes() {
        document.querySelectorAll('iframe').forEach(iframe => {
            const src = iframe.src || iframe.dataset?.src;
            if (src && (
                src.includes('player') ||
                src.includes('embed') ||
                src.includes('video') ||
                src.includes('stream') ||
                src.includes('agl005') ||
                src.includes('play') ||
                src.includes('izle') ||
                src.includes('film') ||
                src.includes('rapidvid') ||
                src.includes('vidmoxy') ||
                src.includes('closeload')
            )) {
                console.log('[VideoFinder] Found player iframe:', src);

                // Send iframe URL to background for tracking
                chrome.runtime.sendMessage({ type: 'foundPlayerIframe', url: src });

                // Check for agl005.tech encoded URL
                if (src.includes('agl005.tech/iframe')) {
                    decodeAgl005Url(src);
                }
            }
        });
    }

    // Decode agl005.tech/vidmoxy encoded URLs
    function decodeAgl005Url(iframeUrl) {
        try {
            // Extract the encoded part from URL like:
            // https://cvt-s2.agl005.tech/iframe/1150/aHRWcHM6Ly9hb-QtY2RuLTEu...!
            const match = iframeUrl.match(/\/iframe\/\d+\/([^!]+)/);
            if (!match) return;

            let encoded = match[1];

            // Replace URL-safe base64 chars
            encoded = encoded.replace(/-/g, '+').replace(/_/g, '/');

            // Decode base64
            let decoded = atob(encoded);

            // Fix character replacements used by vidmoxy
            decoded = decoded
                .replace(/htVps/g, 'https')
                .replace(/aoä/g, 'amd')
                .replace(/strgám/g, 'stream')
                .replace(/strg.m/g, 'stream');

            // Try to extract a valid URL
            const urlMatch = decoded.match(/https?:\/\/[^\s"'<>]+/);
            if (urlMatch) {
                let videoUrl = urlMatch[0];

                // Add playlist.m3u8 if it ends with /
                if (videoUrl.endsWith('/')) {
                    videoUrl += 'playlist.m3u8';
                } else if (!videoUrl.includes('.m3u8')) {
                    videoUrl += '/playlist.m3u8';
                }

                console.log('[VideoFinder] Decoded vidmoxy URL:', videoUrl);
                chrome.runtime.sendMessage({ type: 'foundVideo', url: videoUrl });
            }
        } catch (e) {
            console.log('[VideoFinder] Decode error:', e);
        }
    }

    // Intercept XHR and Fetch to catch video URLs
    function interceptRequests() {
        // Intercept XHR
        const originalXHROpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function (method, url) {
            if (typeof url === 'string') {
                VIDEO_PATTERNS.forEach(pattern => {
                    if (pattern.test(url)) {
                        chrome.runtime.sendMessage({ type: 'foundVideo', url });
                    }
                });
            }
            return originalXHROpen.apply(this, arguments);
        };

        // Intercept Fetch
        const originalFetch = window.fetch;
        window.fetch = function (url, options) {
            if (typeof url === 'string') {
                VIDEO_PATTERNS.forEach(pattern => {
                    if (pattern.test(url)) {
                        chrome.runtime.sendMessage({ type: 'foundVideo', url });
                    }
                });
            }
            return originalFetch.apply(this, arguments);
        };
    }

    // Observe DOM changes for dynamically loaded videos
    function observeDOM() {
        const observer = new MutationObserver((mutations) => {
            mutations.forEach(mutation => {
                mutation.addedNodes.forEach(node => {
                    if (node.nodeType === 1) { // Element node
                        if (node.tagName === 'VIDEO' || node.tagName === 'IFRAME') {
                            setTimeout(scanVideoElements, 500);
                            setTimeout(scanIframes, 500);
                        }
                        if (node.querySelectorAll) {
                            const videos = node.querySelectorAll('video, iframe');
                            if (videos.length > 0) {
                                setTimeout(scanVideoElements, 500);
                                setTimeout(scanIframes, 500);
                            }
                        }
                    }
                });
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    // Initialize
    function init() {
        console.log('[VideoFinder] Content script loaded');

        // Initial scans
        scanPageSource();
        scanVideoElements();
        scanIframes();

        // Set up interceptors and observers
        interceptRequests();
        observeDOM();

        // Rescan after a delay (for lazy-loaded content)
        setTimeout(() => {
            scanPageSource();
            scanVideoElements();
        }, 3000);
    }

    // Wait for DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
